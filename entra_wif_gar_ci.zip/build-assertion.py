#!/usr/bin/env python3
"""
build-assertion.py — buduje client assertion (JWT) podpisaną kluczem prywatnym x509,
do uwierzytelnienia app-only w Entra ID (certificate credentials flow).

Wejście przez zmienne środowiskowe:
  TENANT_ID    - Directory (tenant) ID
  CLIENT_ID    - Application (client) ID
  CERT_KEY     - ścieżka do klucza prywatnego PEM
  CERT_PUB     - ścieżka do certyfikatu publicznego PEM/.cer

Wyjście: na stdout wypisuje samą assertion (JWT), gotową do curl.
"""
import os, sys, json, time, uuid, base64, hashlib
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography import x509

def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")

def need(name: str) -> str:
    v = os.environ.get(name)
    if not v:
        sys.exit(f"BŁĄD: brak zmiennej środowiskowej {name}")
    return v

tenant    = need("TENANT_ID")
client_id = need("CLIENT_ID")
key_path  = need("CERT_KEY")
pub_path  = need("CERT_PUB")

with open(key_path, "rb") as f:
    key = serialization.load_pem_private_key(f.read(), password=None)

with open(pub_path, "rb") as f:
    cert = x509.load_pem_x509_certificate(f.read())

# x5t = base64url( SHA1(DER) ) — thumbprint dopasowywany do certyfikatu wgranego w Entra
der = cert.public_bytes(serialization.Encoding.DER)
x5t = b64url(hashlib.sha1(der).digest())

now = int(time.time())
header  = {"alg": "RS256", "typ": "JWT", "x5t": x5t}
payload = {
    "aud": f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
    "iss": client_id,
    "sub": client_id,
    "jti": str(uuid.uuid4()),
    "nbf": now,
    "exp": now + 300,      # assertion żyje 5 min — zużywana natychmiast
    "iat": now,
}

signing_input = (
    f"{b64url(json.dumps(header, separators=(',',':')).encode())}."
    f"{b64url(json.dumps(payload, separators=(',',':')).encode())}"
)
signature = key.sign(signing_input.encode(), padding.PKCS1v15(), hashes.SHA256())
sys.stdout.write(f"{signing_input}.{b64url(signature)}")
